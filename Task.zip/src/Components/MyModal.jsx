import React from 'react'

const MyModal = () => {
  return (
    <div>MyModal</div>
  )
}

export default MyModal